export default function Page() {
    return (
        <h1>Main page when logged-in</h1>
    )
}