import { AuthForm } from "./_components/auth-form";

export default function Page() {

    return (
        <div className="w-screen h-screen flex items-center">
            <AuthForm/>
        </div>
    )
}