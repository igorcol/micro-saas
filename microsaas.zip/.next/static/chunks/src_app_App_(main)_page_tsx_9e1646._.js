(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_App_(main)_page_tsx_9e1646._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_App_(main)_page_tsx_9e1646._.js",
  "chunks": [
    "static/chunks/node_modules_0cd500._.js",
    "static/chunks/src_7edb03._.js"
  ],
  "source": "dynamic"
});
