(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_App_page_tsx_5f6611._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_App_page_tsx_5f6611._.js",
  "chunks": [
    "static/chunks/_5e2eab._.js"
  ],
  "source": "dynamic"
});
