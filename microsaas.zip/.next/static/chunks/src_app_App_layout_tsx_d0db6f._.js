(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_App_layout_tsx_d0db6f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_App_layout_tsx_d0db6f._.js",
  "chunks": [
    "static/chunks/node_modules_d1182a._.js",
    "static/chunks/src_3a550d._.js"
  ],
  "source": "dynamic"
});
