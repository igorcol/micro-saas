-- AlterTable
ALTER TABLE "Todo" ADD COLUMN "doneAt" DATETIME;
